﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fiftyRandoms
{
    public partial class frm50Randoms : Form
    {
        private int totalRandoms = 0;
        private String randomString = "?";
        private String error = "Sorry, No more than 50 Randoms!\nPress Clear for another round.";
        public frm50Randoms()
        {   

            InitializeComponent();
            this.labRandoms.Text = this.randomString;
            
          
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnGet_Click(object sender, EventArgs e)
        {
            if (this.randomString.Length == 1) {
                this.randomString = "";    
            }
            if (totalRandoms < 50)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append(this.randomString);
                sb.Append(this.getTenRandoms());
                this.randomString = sb.ToString();
                // this.randomString = this.randomString + getTenRandoms();
                this.labRandoms.Text = this.randomString;
                totalRandoms += 10;
            }
            else {
                this.labErr.Text = this.error;
                //, No more than 50 Randoms! \n Press Clear for another round.";
            }
        }

        private String getTenRandoms() {
            int[] tenRandoms = new int[10];
            int prev = 10;
            Random rand = new Random();
            for (int i = 0; i < 10; i++)
            {
                while (true)
                {
                    int curNum = rand.Next(-9, 10);
                    //curNum -= 10;
                    if (curNum == prev)
                    {
                        continue;
                    }
                    else
                    {
                        tenRandoms[i] = curNum;
                        prev = curNum;
                        break;
                    }
                }
            }

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 10; i++) {
                sb.Append(Convert.ToString(tenRandoms[i]));
                sb.Append("  ");
            }
            sb.Append("\n");
            return sb.ToString();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.randomString = "?";
            this.labRandoms.Text = this.randomString;
            this.totalRandoms = 0;
            this.labErr.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frm50Randoms_Load(object sender, EventArgs e)
        {

        }
    }
}
