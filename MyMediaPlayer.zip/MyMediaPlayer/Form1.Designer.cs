﻿
namespace MyMediaPlayer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.lbVideos = new System.Windows.Forms.ListBox();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnLoad = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbWmiv = new System.Windows.Forms.RadioButton();
            this.rbMp4 = new System.Windows.Forms.RadioButton();
            this.rbAvi = new System.Windows.Forms.RadioButton();
            this.txtFileName = new System.Windows.Forms.TextBox();
            this.wmpPlayer = new AxWMPLib.AxWindowsMediaPlayer();
            this.lblRadBtns = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.wmpPlayer)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.label1.Location = new System.Drawing.Point(28, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select a video to play:";
            // 
            // lbVideos
            // 
            this.lbVideos.FormattingEnabled = true;
            this.lbVideos.Location = new System.Drawing.Point(30, 43);
            this.lbVideos.Name = "lbVideos";
            this.lbVideos.Size = new System.Drawing.Size(201, 147);
            this.lbVideos.TabIndex = 1;
            // 
            // btnRemove
            // 
            this.btnRemove.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.btnRemove.Location = new System.Drawing.Point(31, 205);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(98, 28);
            this.btnRemove.TabIndex = 2;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click_1);
            // 
            // btnLoad
            // 
            this.btnLoad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.btnLoad.Location = new System.Drawing.Point(135, 205);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(98, 28);
            this.btnLoad.TabIndex = 3;
            this.btnLoad.Text = "Load";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click_1);
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.btnAdd.Location = new System.Drawing.Point(135, 391);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(98, 28);
            this.btnAdd.TabIndex = 4;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click_1);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbWmiv);
            this.groupBox1.Controls.Add(this.rbMp4);
            this.groupBox1.Controls.Add(this.rbAvi);
            this.groupBox1.Location = new System.Drawing.Point(33, 352);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 33);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            // 
            // rbWmiv
            // 
            this.rbWmiv.AutoSize = true;
            this.rbWmiv.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.rbWmiv.Location = new System.Drawing.Point(138, 10);
            this.rbWmiv.Name = "rbWmiv";
            this.rbWmiv.Size = new System.Drawing.Size(56, 20);
            this.rbWmiv.TabIndex = 2;
            this.rbWmiv.TabStop = true;
            this.rbWmiv.Text = ".wmv";
            this.rbWmiv.UseVisualStyleBackColor = true;
            // 
            // rbMp4
            // 
            this.rbMp4.AutoSize = true;
            this.rbMp4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.rbMp4.Location = new System.Drawing.Point(65, 10);
            this.rbMp4.Name = "rbMp4";
            this.rbMp4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.rbMp4.Size = new System.Drawing.Size(55, 20);
            this.rbMp4.TabIndex = 1;
            this.rbMp4.TabStop = true;
            this.rbMp4.Text = ".mp4";
            this.rbMp4.UseVisualStyleBackColor = true;
            // 
            // rbAvi
            // 
            this.rbAvi.AutoSize = true;
            this.rbAvi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.rbAvi.Location = new System.Drawing.Point(0, 10);
            this.rbAvi.Name = "rbAvi";
            this.rbAvi.Size = new System.Drawing.Size(47, 20);
            this.rbAvi.TabIndex = 0;
            this.rbAvi.TabStop = true;
            this.rbAvi.Text = ".avi";
            this.rbAvi.UseVisualStyleBackColor = true;
            // 
            // txtFileName
            // 
            this.txtFileName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.txtFileName.Location = new System.Drawing.Point(31, 314);
            this.txtFileName.Name = "txtFileName";
            this.txtFileName.Size = new System.Drawing.Size(200, 21);
            this.txtFileName.TabIndex = 6;
            // 
            // wmpPlayer
            // 
            this.wmpPlayer.Enabled = true;
            this.wmpPlayer.Location = new System.Drawing.Point(254, 43);
            this.wmpPlayer.Name = "wmpPlayer";
            this.wmpPlayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("wmpPlayer.OcxState")));
            this.wmpPlayer.Size = new System.Drawing.Size(456, 378);
            this.wmpPlayer.TabIndex = 7;
            // 
            // lblRadBtns
            // 
            this.lblRadBtns.AutoSize = true;
            this.lblRadBtns.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.lblRadBtns.Location = new System.Drawing.Point(33, 272);
            this.lblRadBtns.Name = "lblRadBtns";
            this.lblRadBtns.Size = new System.Drawing.Size(45, 16);
            this.lblRadBtns.TabIndex = 8;
            this.lblRadBtns.Text = "label2";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(736, 450);
            this.Controls.Add(this.lblRadBtns);
            this.Controls.Add(this.wmpPlayer);
            this.Controls.Add(this.txtFileName);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnLoad);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.lbVideos);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "My Media Player";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.wmpPlayer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lbVideos;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbWmiv;
        private System.Windows.Forms.RadioButton rbMp4;
        private System.Windows.Forms.RadioButton rbAvi;
        private System.Windows.Forms.TextBox txtFileName;
        private AxWMPLib.AxWindowsMediaPlayer wmpPlayer;
        private System.Windows.Forms.Label lblRadBtns;
    }
}

