﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyMediaPlayer
{
    public partial class Form1 : Form
    {
        List<string> allVideos = new List<string>();
        string currentFile = "";
        string currentExtension = "";
        public Form1()
        {
            InitializeComponent();
            this.allVideos.Add("Water4K.mp4");
            this.allVideos.Add("Sintel.avi");
            this.lbVideos.Items.Add("Sintel");
            this.lbVideos.Items.Add("Water4K");
            this.rbAvi.Text = ".avi";
            this.rbMp4.Text = ".mp4";
            this.rbWmiv.Text = ".wmv";

            this.rbAvi.CheckedChanged += extension;
            this.rbMp4.CheckedChanged += extension;
            this.rbWmiv.CheckedChanged += extension;
            this.lblRadBtns.Text = "Enter filename of a new video \nto add ot the list";
        }

        private void extension(object sender, EventArgs e)
        {
            RadioButton selected = ((RadioButton)sender);
            this.currentExtension = selected.Text;
        }

        private void clean()
        {
            this.txtFileName.Text = "";
            this.rbAvi.Checked = false;
            this.rbMp4.Checked = false;
            this.rbWmiv.Checked = false;
        }

        private bool duplicate()
        {
            foreach (var listItem in this.lbVideos.Items)
            {
                if (listItem.ToString().ToLower().Equals(this.currentFile.ToLower()))
                {
                    return true;
                }
            }

            return false;
        }

        private bool presentFile()
        {
            if (this.txtFileName.Text.Length == 0)
            {
                return false;
            }
            else
            {
                this.currentFile = this.txtFileName.Text;
                return true;
            }
        }

        private void btnRemove_Click_1(object sender, EventArgs e)
        {
            if (this.lbVideos.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a video to remove", "ERROR");
                return;
            }

            string remove = Convert.ToString(this.lbVideos.SelectedItem);
            this.lbVideos.Items.RemoveAt(this.lbVideos.SelectedIndex);

            string removeVideo = null;
            foreach (string video in this.allVideos)
            {

                if (video.Contains(remove))
                {
                    removeVideo = video;
                }

            }

            if (removeVideo != null)
            {
                this.allVideos.Remove(removeVideo);
            }

        }

        private void btnLoad_Click_1(object sender, EventArgs e)
        {
            if (this.lbVideos.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a video to load", "ERROR");
                return;
            }

            string selected = Convert.ToString(this.lbVideos.SelectedItem);

            string seletedVideo = null;
            foreach (string video in this.allVideos)
            {

                if (video.Contains(selected))
                {
                    seletedVideo = video;
                }

            }

            if (seletedVideo != null)
            {
                this.wmpPlayer.URL = @"C:\Media\" + seletedVideo;
            }
        }

        private void btnAdd_Click_1(object sender, EventArgs e)
        {
            if (!presentFile())
            {
                MessageBox.Show("Please add the filename in the text box", "ERROR");
                return;
            }

            if (!(this.rbAvi.Checked || this.rbWmiv.Checked || this.rbMp4.Checked))
            {
                MessageBox.Show("Please select the extension format", "ERROR");
                return;
            }

            if (duplicate())
            {
                MessageBox.Show("Video name present, select a different name", "ERROR");
                return;
            }

            this.lbVideos.Items.Add(this.currentFile);
            this.allVideos.Add(this.currentFile + this.currentExtension);

            clean();
        }

        
    }
}