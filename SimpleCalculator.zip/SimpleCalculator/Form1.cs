﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleCalculator
{
    public partial class Form1 : Form
    {   double operand1;
        double operand2;
        public Form1()
        {
            InitializeComponent();
            //this.txtOperand1.Focus();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            //System.Windows.Forms.MessageBox.Show("Cannot calculate due to invalid input!      ", "ERROR");
            double firstOperand = this.getOperandOne();
            double secondOperand = this.getOperandTwo();
         
            switch (this.txtOperator.Text) {
                case "*": {
                    double result = Math.Round(firstOperand * secondOperand, 4);
                    this.txtResult.Text = Convert.ToString(result);
                    break;
                }
                case "/": {
                     if (secondOperand.CompareTo(0).Equals(0)) {
                            System.Windows.Forms.MessageBox.Show("Cannot calculate due to invalid input!      ", "ERROR");
                        }
                     double result = Math.Round(firstOperand / secondOperand, 4);
                     //handle divide by zero exception
                     this.txtResult.Text = Convert.ToString(result);
                     break;
                }
                case "+": {
                     double result = Math.Round(firstOperand + secondOperand, 4);
                     this.txtResult.Text = Convert.ToString(result);
                     break;
                }
                case "-": {
                     double result = Math.Round(firstOperand - secondOperand, 4);
                     this.txtResult.Text = Convert.ToString(result);
                     break;
                }
                default:  {
                    System.Windows.Forms.MessageBox.Show("Cannot calculate due to invalid input!      ", "ERROR");
                    break;
                }
            }
            this.txtOperand1.Focus();
        }



        private double getOperandOne() {
            if (!Double.TryParse(this.txtOperand1.Text,out this.operand1)) {
                System.Windows.Forms.MessageBox.Show("Cannot calculate due to invalid input!      ", "ERROR");
            }
            return this.operand1;
        }

        private double getOperandTwo() {
            if (!Double.TryParse(this.txtOperand2.Text, out this.operand2)) {
                System.Windows.Forms.MessageBox.Show("Cannot calculate due to invalid input!      ", "ERROR");
            }
            return this.operand2;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearResult() {
            this.txtResult.Text = "";
        }

        private void txtOperand1_TextChanged(object sender, EventArgs e)
        {
            this.txtResult.Text = "";
        }
    }
}
