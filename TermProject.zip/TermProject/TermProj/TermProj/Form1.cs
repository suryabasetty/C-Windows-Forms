﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Timers;

namespace TermProj
{
    public partial class Form1 : Form
    {

        //all controls used as part of the form.
        Label lblusername = new Label();
        TextBox txtusername = new TextBox();
        Button btnEnter = new Button();
        //screen 2
        Label lblSelectGame = new Label();
        PictureBox pbGameOne = new PictureBox();
        PictureBox pbGameTwo = new PictureBox();
        PictureBox pbGameThree = new PictureBox();
        Button btnSelectOne = new Button();
        Button btnSelectTwo = new Button();
        Button btnSelectThree = new Button();
        //game screen controls

        Button btnPause = new Button();
        Button btnAbort = new Button();
        Button btnSolution = new Button();
        Button btnNew = new Button();
        Button btnUndo = new Button();

        TextBox txtTimer = new TextBox();
        bool isSol = false;
        Label lblGameOneOver = new Label();
        Button btnUseOneGameTwo = new Button();
        Button btnStartNewGameTwo = new Button();
        Stack<string> recentMoves = new Stack<string>();
        //all variables used as part of the form.
        string filepath;
        string pictureone;
        string picturetwo;
        string picturethree;
        string game;
        string currentGameDate;
        int curMax = 1;//variable usd by game one to capture the maximum enterd value so far
        TextBox[,] gameOneGrid = new TextBox[7, 7];
        TextBox[,] gameTwoGrid = new TextBox[7, 7];
        TextBox[,] gameThreeGrid = new TextBox[7, 7];
        TextBox[,] currentGame;
        string[,] solutionBoard = new string[7, 7];
        string[,] tempBoard = new string[7, 7];
        HashSet<Int32> isPresent = new HashSet<int>();
        int or;
        int oc;
        static Random rand = new Random();
        System.Timers.Timer t;
        int s, h, m, totalTime;
        bool isPaused = false;
        DateTime cdg;
        public Form1()
        {
            InitializeComponent();
            this.Text = "TermProj";
            checkForFile();
            loadAllControls();
            loadFirstScreen();

        }
        //history file
        private void checkForFile()
        {
            string path = Path.GetDirectoryName(Application.ExecutablePath) + "\\termproject.txt";
            if (!System.IO.File.Exists(path))
            {
                System.IO.File.Create(path);
            }
            Console.WriteLine(path);
            this.filepath = path;
            this.pictureone = Path.GetDirectoryName(Application.ExecutablePath) + "\\g1.PNG";
            this.picturetwo = Path.GetDirectoryName(Application.ExecutablePath) + "\\g2.PNG";
            this.picturethree = Path.GetDirectoryName(Application.ExecutablePath) + "\\g3.PNG";
        }
        private void loadAllControls()
        {
            this.FormClosing += OnClosing;
            //set timers
            t = new System.Timers.Timer();
            t.Interval = 1000;
            t.Elapsed += OnTimeEvent;
            totalTime = 0;
            //Game one board creation;
            int sox = 80;
            int soy = 50;
            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    gameOneGrid[i, j] = new TextBox();
                    this.gameOneGrid[i, j].Click += pauseClick;
                    gameOneGrid[i, j].Tag = i + "," + j;
                    this.Controls.Add(gameOneGrid[i, j]);
                    gameOneGrid[i, j].Multiline = true;
                    gameOneGrid[i, j].TextAlign = HorizontalAlignment.Center;
                    Size s = new Size(40, 40);
                    gameOneGrid[i, j].Size = s;
                    Padding pd = gameOneGrid[i, j].Margin;
                    pd.All = 0;
                    pd.Left = 0; pd.Right = 0; pd.Top = 0; pd.Bottom = 0;
                    Point p = new Point(sox, soy);
                    gameOneGrid[i, j].Location = p;
                    sox += 40;
                    gameOneGrid[i, j].Font = new Font("Arial", 17, FontStyle.Regular);
                    if (i >= 1 && i <= 5 && j >= 1 && j <= 5)
                    {
                        gameOneGrid[i, j].BackColor = Color.AliceBlue;
                        this.gameOneGrid[i, j].TextChanged += gameOneTextChanged;
                        this.gameOneGrid[i, j].Leave += gameOneLeave;
                    }
                    else if ((i == 0 || i == 6 || j == 0 || j == 6) && (i != j) && (i + j != 6))
                    {
                        gameOneGrid[i, j].BackColor = Color.CornflowerBlue;
                    }
                    else
                    {
                        gameOneGrid[i, j].BackColor = Color.YellowGreen;
                    }

                    gameOneGrid[i, j].Visible = false;
                }
                sox = 80;
                soy += 40;
            }

            //Game two board creation;
            int stx = 80;
            int sty = 50;
            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    gameTwoGrid[i, j] = new TextBox();
                    this.gameTwoGrid[i, j].Click += pauseClick;
                    gameTwoGrid[i, j].Tag = i + "," + j;
                    this.Controls.Add(gameTwoGrid[i, j]);
                    gameTwoGrid[i, j].Multiline = true;
                    gameTwoGrid[i, j].TextAlign = HorizontalAlignment.Center;
                    Size s = new Size(40, 40);
                    gameTwoGrid[i, j].Size = s;
                    Padding pd = gameTwoGrid[i, j].Margin;
                    pd.All = 0;
                    pd.Left = 0; pd.Right = 0; pd.Top = 0; pd.Bottom = 0;
                    Point p = new Point(stx, sty);
                    gameTwoGrid[i, j].Location = p;
                    stx += 40;
                    gameTwoGrid[i, j].Font = new Font("Arial", 17, FontStyle.Regular);
                    if (i >= 1 && i <= 5 && j >= 1 && j <= 5)
                    {
                        gameTwoGrid[i, j].BackColor = Color.AliceBlue;
                        gameTwoGrid[i, j].ReadOnly = true;
                    }
                    else if ((i == 0 || i == 6 || j == 0 || j == 6) && (i != j) && (i + j != 6))
                    {
                        gameTwoGrid[i, j].BackColor = Color.CornflowerBlue;
                        this.gameTwoGrid[i, j].TextChanged += gameTwoTextChanged;
                        this.gameTwoGrid[i, j].Leave += gameTwoLeave;
                    }
                    else
                    {
                        gameTwoGrid[i, j].BackColor = Color.YellowGreen;
                        this.gameTwoGrid[i, j].TextChanged += gameTwoTextChanged;
                        this.gameTwoGrid[i, j].Leave += gameTwoLeave;
                    }

                    gameTwoGrid[i, j].Visible = false;

                    
                }
                stx = 80;
                sty += 40;
            }

            //Game three board creation;
            int srx = 80;
            int sry = 50;
            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    gameThreeGrid[i, j] = new TextBox();
                    this.gameThreeGrid[i, j].Click += pauseClick;
                    gameThreeGrid[i, j].Tag = i + "," + j;
                    this.Controls.Add(gameThreeGrid[i, j]);
                    gameThreeGrid[i, j].Multiline = true;
                    gameThreeGrid[i, j].TextAlign = HorizontalAlignment.Center;
                    Size s = new Size(40, 40);
                    gameThreeGrid[i, j].Size = s;
                    Padding pd = gameThreeGrid[i, j].Margin;
                    pd.All = 0;
                    pd.Left = 0; pd.Right = 0; pd.Top = 0; pd.Bottom = 0;
                    Point p = new Point(srx, sry);
                    gameThreeGrid[i, j].Location = p;
                    srx += 40;
                    gameThreeGrid[i, j].Font = new Font("Arial", 17, FontStyle.Regular);
                    if (i >= 1 && i <= 5 && j >= 1 && j <= 5)
                    {
                        gameThreeGrid[i, j].BackColor = Color.AliceBlue;
                        this.gameThreeGrid[i, j].TextChanged += gameThreeTextChanged;
                        this.gameThreeGrid[i, j].Leave += gameThreeLeave;

                    }
                    else if ((i == 0 || i == 6 || j == 0 || j == 6) && (i != j) && (i + j != 6))
                    {
                        gameThreeGrid[i, j].BackColor = Color.CornflowerBlue;
                        gameThreeGrid[i, j].ReadOnly = true;
                        
                    }
                    else
                    {
                        gameThreeGrid[i, j].BackColor = Color.YellowGreen;
                        gameThreeGrid[i, j].ReadOnly = true;
                    }

                    gameThreeGrid[i, j].Visible = false;
                }
                srx = 80;
                sry += 40;
            }
            //Game one over options
            this.lblGameOneOver.Text = "use this game 1 for game 2?";
            this.lblGameOneOver.Visible = false;
            this.lblGameOneOver.Font = new Font("Arial", 14, FontStyle.Bold);
            Point overLabelLocation = new Point(75, 78);
            Size lso = new Size(450, 25);
            this.lblGameOneOver.Size = lso;
            this.lblGameOneOver.Location = overLabelLocation;
            this.Controls.Add(this.lblGameOneOver);
            this.lblGameOneOver.AutoSize = false;

            this.btnUseOneGameTwo.Text = "Use";
            this.btnUseOneGameTwo.Font = new Font("Arial", 14, FontStyle.Bold);
            Point btnLocation1 = new Point(156, 200);
            this.btnUseOneGameTwo.Location = btnLocation1;
            Size b1s = new Size(100, 40);
            this.btnUseOneGameTwo.Size = b1s;
            this.btnUseOneGameTwo.Click += BtnUseOneGameTwo_Click; ;
            this.Controls.Add(this.btnUseOneGameTwo);
            this.btnUseOneGameTwo.Visible = false;


            this.btnStartNewGameTwo.Text = "New";
            this.btnStartNewGameTwo.Font = new Font("Arial", 14, FontStyle.Bold);
            this.btnStartNewGameTwo.Location = new Point(276, 200);
            this.btnStartNewGameTwo.Size = new Size(100, 40);
            this.btnStartNewGameTwo.Click += gameTwoScreen;
            this.Controls.Add(this.btnStartNewGameTwo);
            this.btnStartNewGameTwo.Visible = false;


            //first label
            this.lblusername.Text = "Enter username, You have 300 Seconds to finish the game";
            this.lblusername.Visible = false;
            this.lblusername.Font = new Font("Arial", 14, FontStyle.Bold);
            Point userLabelLocation = new Point(75, 78);
            Size ls = new Size(550, 25);
            this.lblusername.Size = ls;
            this.lblusername.Location = userLabelLocation;
            this.Controls.Add(this.lblusername);
            this.lblusername.AutoSize = false;

            //username text
            this.txtusername.Font = new Font("Arial", 14, FontStyle.Regular);
            this.txtusername.Visible = false;
            Point txtBoxLocation = new Point(216, 150);
            Size ts = new Size(140, 25);
            this.txtusername.Size = ts;
            this.txtusername.Location = txtBoxLocation;
            this.Controls.Add(this.txtusername);

            //enter button
            this.btnEnter.Text = "Enter";
            this.btnEnter.Font = new Font("Arial", 14, FontStyle.Bold);
            Point btnLocation = new Point(236, 200);
            this.btnEnter.Location = btnLocation;
            Size bs = new Size(100, 40);
            this.btnEnter.Size = bs;
            this.btnEnter.Click += BtnEnter_Click;
            this.Controls.Add(this.btnEnter);
            this.btnEnter.Visible = false;

            Size s1 = new Size(150, 150);
            Point p1 = new Point(35, 68);
            this.pbGameOne.Size = s1;
            this.pbGameOne.Location = p1;
            this.pbGameOne.Visible = false;
            this.pbGameOne.SizeMode = PictureBoxSizeMode.StretchImage;
            this.pbGameOne.Image = Image.FromFile(this.pictureone);
            this.pbGameOne.Tag = "one";
            this.pbGameOne.Click += pictureClick;
            this.Controls.Add(this.pbGameOne);

            Size s2 = new Size(150, 150);
            Point p2 = new Point(220, 68);
            this.pbGameTwo.Size = s2;
            this.pbGameTwo.Location = p2;
            this.pbGameTwo.Visible = false;
            this.pbGameTwo.SizeMode = PictureBoxSizeMode.StretchImage;
            this.pbGameTwo.Image = Image.FromFile(this.picturetwo);
            this.pbGameTwo.Tag = "two";
            this.pbGameTwo.Click += pictureClick;
            this.Controls.Add(this.pbGameTwo);

            Size s3 = new Size(150, 150);
            Point p3 = new Point(405, 68);
            this.pbGameThree.Size = s3;
            this.pbGameThree.Location = p3;
            this.pbGameThree.Visible = false;
            this.pbGameThree.SizeMode = PictureBoxSizeMode.StretchImage;
            this.pbGameThree.Image = Image.FromFile(this.picturethree);
            this.pbGameThree.Tag = "three";
            this.pbGameThree.Click += pictureClick;
            this.Controls.Add(this.pbGameThree);


            //configure buttons to select game
            this.btnSelectOne.Text = "Game One";
            this.btnSelectOne.Font = new Font("Arial", 11, FontStyle.Bold);
            Point btnone = new Point(35, 240);
            this.btnSelectOne.Location = btnone;
            this.btnSelectOne.Tag = "one";
            Size bs1 = new Size(150, 30);
            this.btnSelectOne.Size = bs1;
            this.btnSelectOne.Click += gameOneScreen;
            this.btnSelectOne.Visible = false;
            this.Controls.Add(this.btnSelectOne);

            this.btnSelectTwo.Text = "Game Two";
            this.btnSelectTwo.Font = new Font("Arial", 11, FontStyle.Bold);
            Point btntwo = new Point(220, 240);
            this.btnSelectTwo.Location = btntwo;
            this.btnSelectTwo.Tag = "two";
            Size bs2 = new Size(150, 30);
            this.btnSelectTwo.Size = bs2;
            this.btnSelectTwo.Click += gameTwoScreen;
            this.btnSelectTwo.Visible = false;
            this.Controls.Add(this.btnSelectTwo);

            this.btnSelectThree.Text = "Game Three";
            this.btnSelectThree.Font = new Font("Arial", 11, FontStyle.Bold);
            Point btnthree = new Point(405, 240);
            this.btnSelectThree.Location = btnthree;
            Size bs3 = new Size(150, 30);
            this.btnSelectThree.Size = bs3;
            this.btnSelectThree.Tag = "three";
            this.btnSelectThree.Click += gameThreeScreen;
            this.btnSelectThree.Visible = false;
            this.Controls.Add(this.btnSelectThree);


            //configure the label sttemnet in second screen

            this.lblSelectGame.Text = "Please click on pictured for instructions and selct game to proceed";
            this.lblSelectGame.Visible = false;
            this.lblSelectGame.Font = new Font("Arial", 12, FontStyle.Bold);
            Point sll = new Point(35, 300);
            Size sls = new Size(600, 25);
            this.lblSelectGame.Size = sls;
            this.lblSelectGame.Location = sll;
            this.Controls.Add(this.lblSelectGame);
            this.lblSelectGame.AutoSize = false;

            //ingame options
            this.btnPause.Text = "Pause";
            this.btnAbort.Text = "Abort";
            this.btnSolution.Text = "Solution";
            this.btnNew.Text = "New";
            this.btnUndo.Text = "Undo";

            Point timerLocation = new Point(450, 40);
            Point undoLocation = new Point(450, 90);
            Point pauseLocation = new Point(450, 140);
            Point newLocation = new Point(450, 190);
            Point abortLocation = new Point(450, 240);
            Point solutionLocation = new Point(450, 290);

            Size sz = new Size(110, 35);
            btnAbort.Size = sz;
            btnPause.Size = sz;
            btnSolution.Size = sz;
            txtTimer.Size = sz;
            btnNew.Size = sz;
            btnUndo.Size = sz;

            btnAbort.Location = abortLocation;
            btnPause.Location = pauseLocation;
            btnSolution.Location = solutionLocation;
            txtTimer.Location = timerLocation;
            btnNew.Location = newLocation;
            btnUndo.Location = undoLocation;

            btnAbort.Font = new Font("Arial", 14, FontStyle.Regular);
            btnPause.Font = new Font("Arial", 14, FontStyle.Regular);
            btnSolution.Font = new Font("Arial", 14, FontStyle.Regular);
            txtTimer.Font = new Font("Arial", 10, FontStyle.Regular);
            btnNew.Font = new Font("Arial", 14, FontStyle.Regular);
            btnUndo.Font = new Font("Arial", 14, FontStyle.Regular);

            this.btnPause.Visible = false;
            this.btnAbort.Visible = false;
            this.btnSolution.Visible = false;
            this.txtTimer.Visible = false;
            this.btnNew.Visible = false;
            this.btnUndo.Visible = false;

            this.btnUndo.Click += BtnUndo_Click;
            this.btnPause.Click += BtnPause_Click;
            this.btnNew.Click += BtnNew_Click;
            this.btnAbort.Click += BtnAbort_Click;
            this.btnSolution.Click += BtnSolution_Click;

            this.Controls.Add(btnPause);
            this.Controls.Add(btnAbort);
            this.Controls.Add(btnSolution);
            this.Controls.Add(txtTimer);
            this.Controls.Add(btnNew);
            this.Controls.Add(btnUndo);
            txtTimer.TextAlign = HorizontalAlignment.Center;


        }

        private void OnClosing(object sender, FormClosingEventArgs e)
        {
            saveAndCloseCurrentGame();
        }

        

        private void BtnUseOneGameTwo_Click(object sender, EventArgs e)
        {
            if (isPaused)
            {
                btnPause.Text = "Pause";
                isPaused = false;
            }
            isSol = true;
            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    this.gameTwoGrid[i, j].ReadOnly = false;
                    this.gameTwoGrid[i, j].Text = "";
                }
            }
            isSol = false;
            currentGame = gameTwoGrid;
            currentGameDate = DateTime.Now.ToString();
            cdg = DateTime.Now;
            game = "two";
            isSol = false;
            this.or = rand.Next(1, 6);
            this.oc = rand.Next(1, 6);
            //this.solutionBoard[or, oc] = "1";
            this.gameTwoGrid[or, oc].Text = "1";
            this.gameTwoGrid[or, oc].ReadOnly = true;
            invisibleAllControls();


            this.btnPause.Visible = true;
            this.btnAbort.Visible = true;
            this.btnSolution.Visible = true;
            this.txtTimer.Visible = true;
            this.btnNew.Visible = true;
            // this.btnUndo.Visible = true;
            //getOneSolution(or, oc);
            isSol = false;
            solutionBoard = new string[7, 7];
            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    this.gameTwoGrid[i, j].Visible = true;
                    this.gameTwoGrid[i, j].Text = tempBoard[i, j];
                    solutionBoard[i, j] = tempBoard[i, j];
                }
            }
            t.Start();
        }

        private void pauseClick(object sender, EventArgs e)
        {
            if (isPaused)
            {
                btnPause.Text = "Pause";
                t.Start();
                isPaused = false;
            }
        }

        private void BtnAbort_Click(object sender, EventArgs e)
        {
            saveAndCloseCurrentGame();
            loadInGameOptions();

        }

        private void BtnNew_Click(object sender, EventArgs e)
        {
            saveAndCloseCurrentGame();
            switch (game) {
                case "one":
                    {
                        gameOneScreen(null, null);
                        break;
                    }
                case "two":
                    {
                        gameTwoScreen(null, null);
                        break;
                    }
                case "three":
                    {
                        gameThreeScreen(null, null);
                        break;
                    }
                default:
                    {
                        break;
                    }

            }
        }

        private void BtnPause_Click(object sender, EventArgs e)
        {

            if (isPaused)
            {
                btnPause.Text = "Pause";
                t.Start();
                isPaused = false;
            }
            else {
                btnPause.Text = "Resume";
                t.Stop();
                isPaused = true;
            }
        }

        private void BtnUndo_Click(object sender, EventArgs e)
        {
            if (this.recentMoves.Count() == 0)
            {
                return;
            }
            string top = this.recentMoves.Pop();
            string[] rcarray = top.Split(',');
            int r = Convert.ToInt32(rcarray[0]);
            int c = Convert.ToInt32(rcarray[1]);
            this.currentGame[r, c].ReadOnly = false;
            int num = Convert.ToInt32(this.currentGame[r, c].Text);
            isPresent.Remove(num);
            this.currentGame[r, c].Text = "";
            if (game.Equals("one") || game.Equals("three")) {
                curMax--;
            }
        }

        private void gameThreeScreen(object sender, EventArgs e)
        {
            if (isPaused)
            {
                btnPause.Text = "Pause";
                isPaused = false;
            }

            isSol = true;
            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    this.gameThreeGrid[i, j].ReadOnly = false;
                    this.gameThreeGrid[i, j].Text = "";
                }
            }
            isSol = false;
            currentGame = gameThreeGrid;
            currentGameDate = DateTime.Now.ToString();
            cdg = DateTime.Now;
            game = "three";
            isSol = false;
            solutionBoard = new string[7, 7];
            this.or = rand.Next(1, 6);
            this.oc = rand.Next(1, 6);
            this.solutionBoard[or, oc] = "1";
            this.gameThreeGrid[or, oc].Text = "1";
            this.gameThreeGrid[or, oc].ReadOnly = true;
            invisibleAllControls();
            

            this.btnPause.Visible = true;
            this.btnAbort.Visible = true;
            this.btnSolution.Visible = true;
            this.txtTimer.Visible = true;
            this.btnNew.Visible = true;
            this.btnUndo.Visible = true;
            getOneSolution(or, oc);
            int[] visited = new int[26];
            visited[1] = 1;
            gameTwoSolution(visited, 1);
           
            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    this.gameThreeGrid[i, j].Visible = true;
                    if (i == or && j == oc) {
                        gameThreeGrid[i, j].Text = "1";
                    }
                    else if (i >= 1 && i <= 5 && j >= 1 && j <= 5)
                    {
                        gameThreeGrid[i, j].Text = "";
                    }
                    else {
                        gameThreeGrid[i, j].Text = solutionBoard[i, j];
                    }
                }
            }
            t.Start();
        }

        private void gameTwoScreen(object sender, EventArgs e)
        {
            if (isPaused)
            {
                btnPause.Text = "Pause";
                isPaused = false;
            }
            isSol = true;
            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    this.gameTwoGrid[i, j].ReadOnly = false;
                    this.gameTwoGrid[i, j].Text = "";
                }
            }
            isSol = false;
            currentGame = gameTwoGrid;
            currentGameDate = DateTime.Now.ToString();
            cdg = DateTime.Now;
            game = "two";
            isSol = false;
            solutionBoard = new string[7, 7];
            this.or = rand.Next(1, 6);
            this.oc = rand.Next(1, 6);
            this.solutionBoard[or, oc] = "1";
            this.gameTwoGrid[or, oc].Text = "1";
            this.gameTwoGrid[or, oc].ReadOnly = true;
            invisibleAllControls();
            

            this.btnPause.Visible = true;
            this.btnAbort.Visible = true;
            this.btnSolution.Visible = true;
            this.txtTimer.Visible = true;
            this.btnNew.Visible = true;
           // this.btnUndo.Visible = true;
            getOneSolution(or, oc);
            isSol = false;
            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    this.gameTwoGrid[i, j].Visible = true;
                    this.gameTwoGrid[i, j].Text = solutionBoard[i, j];
                    if (i <= 5 && i >= 1 && j <= 5 && j >= 1) {
                        gameTwoGrid[i, j].ReadOnly = true;
                    }
                }
            }
            t.Start();
        }

        private void gameOneScreen(object sender, EventArgs e)
        {
            if (isPaused) {
                btnPause.Text = "Pause";
                isPaused = false;
            }
            isSol = true;
            for (int i = 0; i < 7; i++) {
                for (int j = 0; j < 7; j++) {
                    this.gameOneGrid[i, j].ReadOnly = false;
                    this.gameOneGrid[i, j].Text = "";
                }
            }
            isSol = false;
            currentGame = gameOneGrid;
            currentGameDate = DateTime.Now.ToString();
            cdg = DateTime.Now;
            game = "one";
            isSol = false;
            this.or = rand.Next(1, 6);
            this.oc = rand.Next(1, 6);
            this.solutionBoard[or, oc] = "1";
            this.gameOneGrid[or, oc].Text = "1";
            this.gameOneGrid[or, oc].ReadOnly = true;
            tempBoard = new string[7, 7];
            invisibleAllControls();
            for (int i = 1; i < 6; i++)
            {
                for (int j = 1; j < 6; j++)
                {
                    this.gameOneGrid[i, j].Visible = true;
               
                }
            }

            this.btnPause.Visible = true;
            this.btnAbort.Visible = true;
            this.btnSolution.Visible = true;
            this.txtTimer.Visible = true;
            this.btnNew.Visible = true;
            this.btnUndo.Visible = true;
            t.Start();
        }

        private List<int[]> getAdjacent(int r, int c)
        {
            int[,] dirs = new int[,] { { 0, 1 }, { 0, -1 }, { 1, 0 }, { -1, 0 }, { 1, 1 }, { -1, 1 }, { -1, -1 }, { 1, -1 } };
            List<int[]> adjacentPoints = new List<int[]>();
            for (int i = 0; i < 8; i++)
            {
                int cr = r + dirs[i, 0];
                int cc = c + dirs[i, 1];
                if (cr >= 1 && cr <= 5 && cc >= 1 && cc <= 5)
                {
                    int[] addPoint = new int[] { cr, cc };
                    adjacentPoints.Add(addPoint);
                }
            }
            return adjacentPoints;
        }

        private void gameOneLeave(object sender, EventArgs e)
        {   

            TextBox currentCell = (TextBox)sender;

            if (isSol || currentCell.Text.Length == 0)
            {
                return;
            }
            string tag = currentCell.Tag.ToString();

            int a = Convert.ToInt32(currentCell.Text);
            
            string[] point = tag.Split(',');
            int cr = Convert.ToInt32(point[0]);
            int cc = Convert.ToInt32(point[1]);
            if (cr == or && cc == oc) {
                return;
            }
            List<int[]> ap = getAdjacent(cr, cc);
            bool isbad = true;
            for (int i = 0; i < ap.Count; i++)
            {
                if (Int32.TryParse(this.gameOneGrid[ap.ElementAt(i)[0], ap.ElementAt(i)[1]].Text, out int b) && b == a - 1)
                {
                    isbad = false;
                }
            }

            HashSet<string> temp = new HashSet<string>();

            for (int i = 1; i < 6; i++) {
                for (int j = 1; j < 6; j++) {
                    if (temp.Count > 0 && gameOneGrid[i, j].Text.Length > 0 && temp.Contains(gameOneGrid[i, j].Text)) {
                        isbad = true;
                    }
                    if (gameOneGrid[i, j].Text.Length > 0)
                        temp.Add(gameOneGrid[i, j].Text);
                }
            }
            if (isbad)
            {
                MessageBox.Show("", "Error");
                currentCell.Text = "";
                currentCell.Focus();
            }
            else if (a == curMax + 1)
            {
                curMax++;
                currentCell.ReadOnly = true;
                string rc = cr + "," + cc;
                this.recentMoves.Push(rc);
                isPresent.Add(a);
            }
            
            if (a == 25)
            {
                t.Stop();
                MessageBox.Show("", "Congratulations");
                showGameOneOverOptions();
            }
        }

        private void showGameOneOverOptions() {
            for (int i = 0; i < 7; i++) {
                for (int j = 0; j < 7; j++) {
                    tempBoard[i, j] = gameOneGrid[i, j].Text;
                }
            }
            saveAndCloseCurrentGame();
            invisibleAllControls();
            this.lblGameOneOver.Visible = true;
            this.btnStartNewGameTwo.Visible = true;
            this.btnUseOneGameTwo.Visible = true;
        }

        private void gameOneTextChanged(object sender, EventArgs e)
        {
            TextBox currentCell = (TextBox)sender;
            if (isSol || currentCell.Text.Length == 0)
            {
                return;
            }
            if (!Int32.TryParse(currentCell.Text, out int a) || a > 25 || a < 1)
            {
                MessageBox.Show("", "Error");
                currentCell.Text = "";
                currentCell.Focus();
            }
        }

        private void gameTwoLeave(object sender, EventArgs e)
        {
            TextBox currentCell = (TextBox)sender;
            if (isSol || currentCell.Text.Length == 0)
            {
                return;
            }
            string[] rc = currentCell.Tag.ToString().Split(',');
            int r = Convert.ToInt32(rc[0]);
            int c = Convert.ToInt32(rc[1]);
            if (r >= 1 && r <= 5 && c >= 1 && c <= 5) {
                return;
            }
            if ((r == 0 && c == 0) || (r == 6 && c == 0) || (r == 0 && c == 6) || (r == 6 && c == 6)) {
                cornerLeave(sender, e);
            }else {
                regularLeave(sender, e);
            }

        }

        private void gameTwoTextChanged(object sender, EventArgs e)
        {
            TextBox currentCell = (TextBox)sender;
            if (isSol || currentCell.Text.Length == 0)
            {
                return;
            }
            if (!Int32.TryParse(currentCell.Text, out int a) || a > 25 || a < 1)
            {
                MessageBox.Show("", "Error");
                currentCell.Text = "";
                currentCell.Focus();
            }
        }

        private void gameThreeLeave(object sender, EventArgs e)
        {
            TextBox currentCell = (TextBox)sender;
            if (isSol || currentCell.Text.Length == 0)
            {
                return;
            }

            string tag = currentCell.Tag.ToString();
            int num = Convert.ToInt32(currentCell.Text);
            string[] point = tag.Split(',');
            int cr = Convert.ToInt32(point[0]);
            int cc = Convert.ToInt32(point[1]);
            if (cr == or && cc == oc)
            {
                return;
            }
            HashSet<Int32> temp = new HashSet<Int32>();
            //temp.Add(1);
            for (int i = 1; i < 6; i++)
            {
                for (int j = 1; j < 6; j++)
                {

                    if (gameThreeGrid[i, j].Text.Length == 0) {
                        continue;
                    }
                    if (temp.Count > 0 && temp.Contains(Convert.ToInt32(gameThreeGrid[i, j].Text)))
                    {
                         MessageBox.Show("Error", "Error");
                         currentCell.Text = "";
                         currentCell.Focus();
                         return;
                    }
                    temp.Add(Convert.ToInt32(gameThreeGrid[i, j].Text));
                    
                }
            }



            int a = Convert.ToInt32(currentCell.Text);
            List<int[]> check = checkPoints(cr, cc);
            bool isOk = false;
            for (int i = 0; i < check.Count; i++) {
                if (Int32.TryParse(this.gameThreeGrid[check.ElementAt(i)[0], check.ElementAt(i)[1]].Text, out int b) && b == a)
                {
                    isOk = true;
                }
            }
            if (!isOk) {
                MessageBox.Show("", "Error");
                currentCell.Text = "";
                currentCell.Focus();
                return;
            }
            List<int[]> ap = getAdjacent(cr, cc);
            bool isbad = true;
            for (int i = 0; i < ap.Count; i++)
            {
                if (Int32.TryParse(this.gameThreeGrid[ap.ElementAt(i)[0], ap.ElementAt(i)[1]].Text, out int b) && b == a - 1)
                {
                    isbad = false;
                }
            }
            if (isbad)
            {
                MessageBox.Show("", "Error");
                currentCell.Text = "";
                currentCell.Focus();
                return;
            }
            else if (a == curMax + 1)
            {
                curMax++;
                currentCell.ReadOnly = true;
                string rc = cr + "," + cc;
                this.recentMoves.Push(rc);
                isPresent.Add(a);
            }
            if (a == 25)
            {
                MessageBox.Show("", "Congratulations");
                saveAndCloseCurrentGame();
                //showGameThreeOverOptions();
            }


        }

        private List<int[]> checkPoints(int r, int c) {
            List<int[]> ans = new List<int[]>();
            int[] right = new int[] { r, 6 };
            int[] left = new int[] { r, 0 };
            int[] top = new int[] {0, c };
            int[] bot = new int[] { 6, c };
            ans.Add(right);
            ans.Add(left);
            ans.Add(top);
            ans.Add(bot);
            int[] lt = new int[] { 0, 0 };
            int[] lb = new int[] { 6, 0 };
            int[] rt = new int[] { 0, 6 };
            int[] rb = new int[] { 6, 6 };
            if (r == 3 && c == 3)
            {
                ans.Add(lt);
                ans.Add(lb);
                ans.Add(rt);
                ans.Add(rb);
            }
            else if (r + c == 6)
            {
                ans.Add(rt);
                ans.Add(lb);
            }
            else if (r == c) {
                ans.Add(lt);
                ans.Add(rb);
            }
            return ans;
        }
        
        private void gameThreeTextChanged(object sender, EventArgs e)
        {
            TextBox currentCell = (TextBox)sender;
            if (isSol || currentCell.Text.Length == 0)
            {
                return;
            }
            if (!Int32.TryParse(currentCell.Text, out int a) || a > 25 || a < 1)
            {
                MessageBox.Show("", "Error");
                currentCell.Text = "";
                currentCell.Focus();
            }
        }


        private void OnTimeEvent(object sender, ElapsedEventArgs e)
        {
            Invoke(new Action(() =>
            {
                s += 1;
                this.totalTime++;
                
                if (s == 60)
                {
                    s = 0;
                    m += 1;
                }
                if (m == 60)
                {
                    m = 0;
                    h += 1;
                }

                this.txtTimer.Text = string.Format("{0}:{1}:{2}", h.ToString().PadLeft(2, '0'), m.ToString().PadLeft(2, '0'), s.ToString().PadLeft(2, '0'));
                if (totalTime == 300)
                {
                    t.Stop();
                    failedGame();
                }
            }));
        }

        private void failedGame() {
            MessageBox.Show("Time Over", "Time Over");
            saveAndCloseCurrentGame();
            loadInGameOptions();
        }

        private void pictureClick(object sender, EventArgs e)
        {
            string s = ((PictureBox)sender).Tag.ToString();
            InstructionForm instructions = new InstructionForm(s);
            instructions.Show();
        }

        private void invisibleAllControls()
        {
            this.btnEnter.Visible = false;
            this.lblusername.Visible = false;
            this.txtusername.Visible = false;

            //second screen
            this.lblSelectGame.Visible = false;
            this.btnSelectOne.Visible = false;
            this.btnSelectTwo.Visible = false;
            this.btnSelectThree.Visible = false;
            this.pbGameOne.Visible = false;
            this.pbGameTwo.Visible = false;
            this.pbGameThree.Visible = false;
            this.btnUndo.Visible = false;
            this.btnStartNewGameTwo.Visible = false;
            this.lblGameOneOver.Visible = false;
            this.btnUseOneGameTwo.Visible = false;
            //game scren
            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    this.gameOneGrid[i, j].Visible = false;
                    this.gameTwoGrid[i, j].Visible = false;
                    this.gameThreeGrid[i, j].Visible = false;

                }
            }

            this.btnPause.Visible = false;
            this.btnAbort.Visible = false;
            this.btnSolution.Visible = false;
            this.txtTimer.Visible = false;
            this.btnNew.Visible = false;
        }

        private void newUserProfileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            invisibleAllControls();
            saveAndCloseCurrentGame();
            loadFirstScreen();
        }

        private void saveAndCloseCurrentGame() {
            t.Stop();
            DateTime snow = DateTime.Now;
            TimeSpan difference = snow.Subtract(cdg);
            int timeSpent = (int)difference.TotalSeconds;
            string gameData = this.txtusername.Text.ToString() + "," + game + "," + currentGameDate + "," + timeSpent;
            solutionBoard = new string[7, 7];
            if (totalTime == 0) {
                return;
            }
            for (int i = 0; i < 7; i++) {
                for (int j = 0; j < 7; j++) {
                    currentGame[i, j].Text = "";
                }
            }
            if (totalTime > 0) {
                File.AppendAllText(this.filepath, gameData + Environment.NewLine);
            }
            recentMoves = new Stack<string>();
            isPresent = new HashSet<int>();
            totalTime = 0;
            //isPaused = false;
            solutionBoard = new string[7, 7];
            s = 0;
            m = 0;
            h = 0;
           // game = "";
           //  currentGame = null;
        }
        private void historyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            HistoryForm hf = new HistoryForm();
            hf.filePath = this.filepath;
            hf.parent = this;
            hf.loadHistory();
            hf.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveAndCloseCurrentGame();
            this.Close();
        }

        private void loadFirstScreen()
        {
            this.txtusername.Text = "";
            invisibleAllControls();
            this.lblusername.Visible = true;
            this.txtusername.Visible = true;
            this.btnEnter.Visible = true;
        }

        private void BtnEnter_Click(object sender, EventArgs e)
        {
            if (this.txtusername.Text.ToString().Length == 0)
            {
                MessageBox.Show("Enter User Name", "Error");
            }
            else
            {
                loadInGameOptions();
            }
        }

        private void loadInGameOptions()
        {
            invisibleAllControls();
            this.pbGameOne.Visible = true;
            this.pbGameTwo.Visible = true;
            this.pbGameThree.Visible = true;
            this.btnSelectOne.Visible = true;
            this.btnSelectTwo.Visible = true;
            this.btnSelectThree.Visible = true;
            this.lblSelectGame.Visible = true;
        }

        private void BtnSolution_Click(object sender, EventArgs e)
        {
            if (game.Equals("one"))
            {
                showOneSol();
            }
            else if (game.Equals("two"))
            {
                showTwoSol();
            }
            else {
                showThreeSol();
            }
        }

        private void showThreeSol() {

            isSol = true;
            t.Stop();
            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    this.gameThreeGrid[i, j].Text = solutionBoard[i, j];
                    this.gameThreeGrid[i, j].ReadOnly = true;
                }
            }
            // saveAndCloseCurrentGame();
            // invisibleAllControls();
        }

        private void showTwoSol() {

            isSol = true;
            t.Stop();
            int[] visited = new int[26];
            visited[1] = 1;
            gameTwoSolution(visited, 1);
            //saveAndCloseCurrentGame();
            //invisibleAllControls();
            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    this.gameTwoGrid[i, j].Text = solutionBoard[i, j];
                    this.gameTwoGrid[i, j].ReadOnly = true;
                }
            }

        }

        private bool gameTwoSolution(int[] visited, int count)
        {
           
            if (count == 25)
            {
                return true;
            }
            int r = rc(count)[0];
            int c = rc(count)[1];
            String[] target = getTargets(r, c, visited);
            for (int i = 0; i < target.Length; i++)
            {
                solutionBoard[r, c] = target[i];
                int v = Int32.Parse(target[i]);
                visited[v] = 1;
                if (gameTwoSolution(visited, count + 1))
                {
                    return true;
                }
                visited[v] = 0;
                solutionBoard[r, c] = null;
            }
            return false;
        }

        private int[] rc(int count)
        {
            int[] ans = new int[2];
            if (count <= 7)
            {
                ans[0] = 0;
                ans[1] = count - 1;
                //return ans;
            }
            else if (count <= 13)
            {
                ans[0] = count - 7;
                ans[1] = 6;
                //return ans;
            }
            else if (count <= 19)
            {
                ans[0] = 6;
                ans[1] = 19 - count;
            }
            else
            {
                ans[0] = 25 - count;
                ans[1] = 0;
            }
            return ans;
        }

        private String[] getTargets(int r, int c, int[] visited)
        {
            // int count = 0;
            List<string> vals = new List<string>();
            if ((r == 0 && c == 0) || (r == 6 && c == 6))
            {
                for (int i = 1; i <= 5; i++)
                {
                    if (visited[Int32.Parse(solutionBoard[i, i])] == 0)
                    {
                        vals.Add(solutionBoard[i, i]);
                    }
                }
            }
            else if ((r == 0 && c == 6) || (r == 6 && c == 0))
            {
                for (int i = 1; i <= 5; i++)
                {
                    if (visited[Int32.Parse(solutionBoard[i, 6 - i])] == 0)
                    {
                        vals.Add(solutionBoard[i, 6 - i]);
                    }
                }
            }
            else if (r == 0 || r == 6)
            {
                for (int i = 1; i <= 5; i++)
                {
                    if (visited[Int32.Parse(solutionBoard[i, c])] == 0)
                    {
                        vals.Add(solutionBoard[i, c]);
                    }
                }
            }
            else
            {
                for (int i = 1; i <= 5; i++)
                {
                    if (visited[Int32.Parse(solutionBoard[r, i])] == 0)
                    {
                        vals.Add(solutionBoard[r, i]);
                    }
                }
            }

            int count = vals.Count;
            String[] ans = new string[count];
            for (int i = 0; i < count; i++)
            {
                ans[i] = vals[i];
            }
            return ans;
        }

        private void showOneSol() {
            isSol = true;
            t.Stop();
            getOneSolution(or, oc);
            for (int i = 1; i < 6; i++)
            {
                for (int j = 1; j < 6; j++)
                {
                    currentGame[i, j].Text = solutionBoard[i, j];
                    currentGame[i, j].Visible = true;
                    currentGame[i, j].ReadOnly = true;
                }
            }
           
            //saveAndCloseCurrentGame();
            //invisibleAllControls();
            
        }

        private bool getOneSolution(int r, int c)
        {
            //Console.WriteLine(r + " " + c);
            int curNum = Int32.Parse(solutionBoard[r, c]);
            if (curNum == 25)
            {
                return true;
            }

            int[,] dir = randomDirs();

            for (int i = 0; i < 8; i++)
            {

                int nr = r + dir[i, 0];
                int nc = c + dir[i, 1];
                if (nr >= 1 && nc >= 1 && nr <= 5 && nc <= 5 && solutionBoard[nr, nc] == null)
                {
                    solutionBoard[nr, nc] = Convert.ToString(curNum + 1);
                    if (!getOneSolution(nr, nc))
                    {
                        solutionBoard[nr, nc] = null;
                    }
                    else
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        private int[,] randomDirs()
        {
            int[] randOrder = new int [] { 4, 3, 1, 0, 6, 5, 7, 2 };
            //int[] randOrder =  randOrderNumber();
            int[,] dirs = new int[,] { { 0, 1 }, { 0, -1 }, { 1, 0 }, { -1, 0 }, { 1, 1 }, { -1, 1 }, { -1, -1 }, { 1, -1 } };
            int[,] randDirs = new int[8, 2];
            for (int i = 0; i < 8; i++)
            {
                randDirs[i, 0] = dirs[randOrder[i], 0];
                randDirs[i, 1] = dirs[randOrder[i], 1];
            }
            return randDirs;
        }

        private int[] randOrderNumber()
        {
            int[] ans = new int[8];
            for (int i = 0; i < 8; i++) { ans[i] = i; }
            int max = 8;
            for (int i = 0; i < 8; i++)
            {

                int index = rand.Next(0, max);
                int temp = ans[max - 1];
                ans[max - 1] = ans[index];
                ans[index] = temp;
                max--;
            }
            return ans;
        }

        private void cornerLeave(object sender, EventArgs e)
        {
            // throw new NotImplementedException();
            TextBox currentCell = (TextBox)sender;
            if (currentCell.Text.Length == 0)
            {
                return;
            }

            string tag = currentCell.Tag.ToString();
            int num = Convert.ToInt32(currentCell.Text);
            HashSet<Int32> temp = new HashSet<Int32>();
            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    if ((i == 0 || i == 6 || j == 0 || j == 6) && (gameTwoGrid[i, j].Text.Length > 0))
                    {
                        if (temp.Count > 0 && temp.Contains(Convert.ToInt32(gameTwoGrid[i, j].Text)))
                        {
                            MessageBox.Show("Error", "Error");
                            currentCell.Text = "";
                            currentCell.Focus();
                            return;
                        }
                        temp.Add(Convert.ToInt32(gameTwoGrid[i, j].Text));
                    }
                }
            }
            

            string[] rc = tag.Split(',');
            int r = Convert.ToInt32(rc[0]);
            int c = Convert.ToInt32(rc[1]);
            if (r == c)
            {
                if (checkRight(num))
                {
                    MessageBox.Show("Error", "Error");
                    currentCell.Text = "";
                    currentCell.Focus();
                    return;
                }
            }
            else
            {
                if (checkLeft(num))
                {
                    currentCell.Text = "";
                    currentCell.Focus();
                    MessageBox.Show("Error", "Error");
                    return;
                }
            }

            if (temp.Count == 24) {
                MessageBox.Show("Congratulations");
                saveAndCloseCurrentGame();
            }
               
        }

        

        private bool checkRight(int num)
        {
            for (int i = 1; i < 6; i++)
            {
                if (this.gameTwoGrid[i, i].Text.Length > 0)
                {
                    if (Convert.ToInt32(this.gameTwoGrid[i, i].Text) == num)
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        private bool checkLeft(int num)
        {
            for (int i = 1; i < 6; i++)
            {
                if (this.gameTwoGrid[i, 6 - i].Text.Length > 0)
                {
                    if (Convert.ToInt32(this.gameTwoGrid[i, 6 - i].Text) == num)
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        private void regularLeave(object sender, EventArgs e)
        {

            //throw new NotImplementedException();
            TextBox currentCell = (TextBox)sender;
            if (currentCell.Text.Length == 0)
            {
                return;
            }
            
            string tag = currentCell.Tag.ToString();
            int num = Convert.ToInt32(currentCell.Text);
            HashSet<Int32> temp = new HashSet<Int32>();
            for (int i = 0; i < 7; i++) {
                for (int j = 0; j < 7; j++) {
                    if ((i == 0 || i == 6 || j == 0 || j == 6) && (gameTwoGrid[i, j].Text.Length > 0)) {
                        if (temp.Count > 0 && temp.Contains(Convert.ToInt32(gameTwoGrid[i, j].Text))) {
                            MessageBox.Show("Error", "Error");
                            currentCell.Text = "";
                            currentCell.Focus();
                            return;
                        }
                        temp.Add(Convert.ToInt32(gameTwoGrid[i, j].Text));
                    }
                }
            }
            
           
            string[] rc = tag.Split(',');
            int r = Convert.ToInt32(rc[0]);
            int c = Convert.ToInt32(rc[1]);
            if (r == 0 || r == 6)
            {
                if (checkCol(c, num))
                {
                     MessageBox.Show("Error", "Error");
                     currentCell.Text = "";
                     currentCell.Focus();
                     return;
                }
            }
            else
            {
               if (checkRow(r, num))
               {
                    MessageBox.Show("Error", "Error");
                    currentCell.Text = "";
                    currentCell.Focus();
                    return;
               }
            }

            if (temp.Count == 24)
            {
                MessageBox.Show("Congratulations");
                saveAndCloseCurrentGame();
            }

        }
        

        private bool checkCol(int c, int num)
        {
            for (int i = 1; i < 6; i++)
            {
                if (this.gameTwoGrid[i, c].Text.Length > 0) {
                    if (Convert.ToInt32(this.gameTwoGrid[i, c].Text) == num)
                    {
                        return false;
                    }
                }
               
            }
            return true;
        }

        private bool checkRow(int r, int num)
        {
            for (int i = 1; i < 6; i++)
            {
                if (this.gameTwoGrid[r, i].Text.Length > 0)
                {
                    if (Convert.ToInt32(this.gameTwoGrid[r, i].Text) == num)
                    {
                        return false;
                    }
                }

            }
            return true;
        }
   
        
    }
}
