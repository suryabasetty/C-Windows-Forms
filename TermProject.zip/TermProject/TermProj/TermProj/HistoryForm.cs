﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace TermProj
{
    public partial class HistoryForm : Form
    {
        public Form parent;

        public string filePath;

        DataTable table = new DataTable();
        public HistoryForm()
        {
            InitializeComponent();
            //loadHistory();
        }

        public void loadHistory()
        {
            table.Columns.Add("Plyer Name", typeof(string));
            table.Columns.Add("Game Type", typeof(string));
            table.Columns.Add("Start Time", typeof(string));
            table.Columns.Add("Time Taken", typeof(string));

            Console.WriteLine(this.filePath);
            fileImport();
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.DataSource = table;
        }

        private void fileImport()
        {

            string[] lines = File.ReadAllLines(this.filePath);
            string[] values;

            //Console.WriteLine(table.Rows.)
            for (int i = 0; i < lines.Length; i++)
            {
                values = lines[i].ToString().Split(',');
                string[] row = new string[values.Length];
                for (int j = 0; j < row.Length; j++)
                {
                    row[j] = values[j];
                }
                table.Rows.Add(row);
            }
        }
    }
}
