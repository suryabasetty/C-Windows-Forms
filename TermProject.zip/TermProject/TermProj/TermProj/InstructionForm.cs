﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TermProj
{
    public partial class InstructionForm : Form
    {
        string game;
        Label lblInstructions = new Label();
        public InstructionForm(string game)
        {
            InitializeComponent();
            this.game = game;
            InitializeComponent();
            showInstructions();
        }
        public void showInstructions()
        {

            switch (game)
            {
                case "one":
                    {
                        this.lblInstructions.Text = "Game one rules";
                        break;

                    }
                case "two":
                    {
                        this.lblInstructions.Text = "Game two rules";
                        break;

                    }
                case "three":
                    {
                        this.lblInstructions.Text = "Game three rules";
                        break;

                    }
                default:
                    {
                        break;
                    }
            }
        }

    }
}
