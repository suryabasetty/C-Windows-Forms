﻿
namespace TextboxArray
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt00 = new System.Windows.Forms.TextBox();
            this.txt10 = new System.Windows.Forms.TextBox();
            this.txt20 = new System.Windows.Forms.TextBox();
            this.txt01 = new System.Windows.Forms.TextBox();
            this.txt11 = new System.Windows.Forms.TextBox();
            this.txt21 = new System.Windows.Forms.TextBox();
            this.txt02 = new System.Windows.Forms.TextBox();
            this.txt12 = new System.Windows.Forms.TextBox();
            this.txt22 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblSum = new System.Windows.Forms.Label();
            this.lblAverage = new System.Windows.Forms.Label();
            this.lblMax = new System.Windows.Forms.Label();
            this.lblMin = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btnEnter = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt00
            // 
            this.txt00.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt00.Location = new System.Drawing.Point(63, 91);
            this.txt00.Name = "txt00";
            this.txt00.Size = new System.Drawing.Size(100, 38);
            this.txt00.TabIndex = 0;
            this.txt00.TextChanged += new System.EventHandler(this.txt02_TextChanged);
            this.txt00.Leave += new System.EventHandler(this.correctTextBox);
            // 
            // txt10
            // 
            this.txt10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt10.Location = new System.Drawing.Point(63, 150);
            this.txt10.Name = "txt10";
            this.txt10.Size = new System.Drawing.Size(100, 38);
            this.txt10.TabIndex = 1;
            this.txt10.TextChanged += new System.EventHandler(this.txt02_TextChanged);
            this.txt10.Leave += new System.EventHandler(this.correctTextBox);
            // 
            // txt20
            // 
            this.txt20.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt20.Location = new System.Drawing.Point(63, 209);
            this.txt20.Name = "txt20";
            this.txt20.Size = new System.Drawing.Size(100, 38);
            this.txt20.TabIndex = 2;
            this.txt20.TextChanged += new System.EventHandler(this.txt02_TextChanged);
            this.txt20.Leave += new System.EventHandler(this.correctTextBox);
            // 
            // txt01
            // 
            this.txt01.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt01.Location = new System.Drawing.Point(178, 91);
            this.txt01.Name = "txt01";
            this.txt01.Size = new System.Drawing.Size(100, 38);
            this.txt01.TabIndex = 3;
            this.txt01.TextChanged += new System.EventHandler(this.txt02_TextChanged);
            this.txt01.Leave += new System.EventHandler(this.correctTextBox);
            // 
            // txt11
            // 
            this.txt11.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt11.Location = new System.Drawing.Point(178, 150);
            this.txt11.Name = "txt11";
            this.txt11.Size = new System.Drawing.Size(100, 38);
            this.txt11.TabIndex = 4;
            this.txt11.TextChanged += new System.EventHandler(this.txt02_TextChanged);
            this.txt11.Leave += new System.EventHandler(this.correctTextBox);
            // 
            // txt21
            // 
            this.txt21.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt21.Location = new System.Drawing.Point(178, 209);
            this.txt21.Name = "txt21";
            this.txt21.Size = new System.Drawing.Size(100, 38);
            this.txt21.TabIndex = 5;
            this.txt21.TextChanged += new System.EventHandler(this.txt02_TextChanged);
            this.txt21.Leave += new System.EventHandler(this.correctTextBox);
            // 
            // txt02
            // 
            this.txt02.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt02.Location = new System.Drawing.Point(293, 91);
            this.txt02.Name = "txt02";
            this.txt02.Size = new System.Drawing.Size(100, 38);
            this.txt02.TabIndex = 6;
            this.txt02.TextChanged += new System.EventHandler(this.txt02_TextChanged);
            this.txt02.Leave += new System.EventHandler(this.correctTextBox);
            // 
            // txt12
            // 
            this.txt12.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt12.Location = new System.Drawing.Point(293, 150);
            this.txt12.Name = "txt12";
            this.txt12.Size = new System.Drawing.Size(100, 38);
            this.txt12.TabIndex = 7;
            this.txt12.TextChanged += new System.EventHandler(this.txt02_TextChanged);
            this.txt12.Leave += new System.EventHandler(this.correctTextBox);
            // 
            // txt22
            // 
            this.txt22.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt22.Location = new System.Drawing.Point(293, 209);
            this.txt22.Name = "txt22";
            this.txt22.Size = new System.Drawing.Size(100, 38);
            this.txt22.TabIndex = 8;
            this.txt22.TextChanged += new System.EventHandler(this.txt02_TextChanged);
            this.txt22.Leave += new System.EventHandler(this.correctTextBox);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(106, 285);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(197, 20);
            this.label1.TabIndex = 9;
            this.label1.Text = "Total boxes with a number:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(174, 316);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 20);
            this.label2.TabIndex = 10;
            this.label2.Text = "Sum of all boxes:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(64, 345);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(239, 20);
            this.label3.TabIndex = 11;
            this.label3.Text = "Average of boxes with a number:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(178, 375);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 20);
            this.label4.TabIndex = 12;
            this.label4.Text = "Max of all boxes:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(182, 404);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(121, 20);
            this.label5.TabIndex = 13;
            this.label5.Text = "Min of all boxes:";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(309, 281);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(25, 25);
            this.lblTotal.TabIndex = 14;
            this.lblTotal.Text = "0";
            // 
            // lblSum
            // 
            this.lblSum.AutoSize = true;
            this.lblSum.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSum.Location = new System.Drawing.Point(309, 311);
            this.lblSum.Name = "lblSum";
            this.lblSum.Size = new System.Drawing.Size(25, 25);
            this.lblSum.TabIndex = 15;
            this.lblSum.Text = "?";
            // 
            // lblAverage
            // 
            this.lblAverage.AutoSize = true;
            this.lblAverage.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAverage.Location = new System.Drawing.Point(309, 340);
            this.lblAverage.Name = "lblAverage";
            this.lblAverage.Size = new System.Drawing.Size(25, 25);
            this.lblAverage.TabIndex = 16;
            this.lblAverage.Text = "?";
            // 
            // lblMax
            // 
            this.lblMax.AutoSize = true;
            this.lblMax.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMax.Location = new System.Drawing.Point(309, 371);
            this.lblMax.Name = "lblMax";
            this.lblMax.Size = new System.Drawing.Size(25, 25);
            this.lblMax.TabIndex = 17;
            this.lblMax.Text = "?";
            // 
            // lblMin
            // 
            this.lblMin.AutoSize = true;
            this.lblMin.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMin.Location = new System.Drawing.Point(309, 400);
            this.lblMin.Name = "lblMin";
            this.lblMin.Size = new System.Drawing.Size(25, 25);
            this.lblMin.TabIndex = 18;
            this.lblMin.Text = "?";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(59, 42);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(374, 20);
            this.label11.TabIndex = 19;
            this.label11.Text = "Enter or update one integer a time in any box below:";
            // 
            // btnEnter
            // 
            this.btnEnter.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnter.Location = new System.Drawing.Point(434, 150);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(75, 38);
            this.btnEnter.TabIndex = 20;
            this.btnEnter.Text = "Enter";
            this.btnEnter.UseVisualStyleBackColor = true;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(434, 209);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 38);
            this.btnClear.TabIndex = 21;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(546, 469);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnEnter);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.lblMin);
            this.Controls.Add(this.lblMax);
            this.Controls.Add(this.lblAverage);
            this.Controls.Add(this.lblSum);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt22);
            this.Controls.Add(this.txt12);
            this.Controls.Add(this.txt02);
            this.Controls.Add(this.txt21);
            this.Controls.Add(this.txt11);
            this.Controls.Add(this.txt01);
            this.Controls.Add(this.txt20);
            this.Controls.Add(this.txt10);
            this.Controls.Add(this.txt00);
            this.Name = "Form1";
            this.Text = "Assignment 5 (ch08)";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt00;
        private System.Windows.Forms.TextBox txt10;
        private System.Windows.Forms.TextBox txt20;
        private System.Windows.Forms.TextBox txt01;
        private System.Windows.Forms.TextBox txt11;
        private System.Windows.Forms.TextBox txt21;
        private System.Windows.Forms.TextBox txt02;
        private System.Windows.Forms.TextBox txt12;
        private System.Windows.Forms.TextBox txt22;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblSum;
        private System.Windows.Forms.Label lblAverage;
        private System.Windows.Forms.Label lblMax;
        private System.Windows.Forms.Label lblMin;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.Button btnClear;
    }
}

