﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TextboxArray
{
    public partial class Form1 : Form
    {
        TextBox[,] txtMatrix;
       
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.txtMatrix = new TextBox[,] { {this.txt00, this.txt01, this.txt02 }, { this.txt10, this.txt11, this.txt12}, {this.txt20, this.txt21, this.txt22} };
        

        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            int? total = null;
            int? sum = null;
            int? min = null ;
            int? max = null ;
            //double? average = null;
          
                for (int i = 0; i < 3; i++) 
                { 
                    for (int j = 0; j < 3; j++)
                    {
                        //Console.WriteLine(this.txtMatrix[i, j].Text);
                        if (this.txtMatrix[i, j].Text.Length == 0) {
                            continue;
                        }
     
                        int num = Int32.Parse(this.txtMatrix[i, j].Text);
                        total = total != null ? total + 1 : 1;
                        sum = sum.HasValue ? sum + num : num;
                        if (min.HasValue)
                        {
                            min = Math.Min((int)min, num);
                        }
                        else {
                            min = num;
                        }

                        if (max.HasValue)
                        {
                            max = Math.Max((int)max, num);
                        }
                        else
                        {
                            max = num;
                        }
                    }
                }  
                
                loadLabels(max, min, sum, total);
        }



        private void loadLabels(int? max, int? min, int? sum, int? total) {
            double? average = null;
            if (total.HasValue && total > 0 && sum.HasValue) {
                    
                  average = (double)sum / (double)total;
                  average = Math.Round((double)average, 2);

             
            }
            

            
            this.lblAverage.Text = average.HasValue ? Convert.ToString(String.Format("{0:0.00}", average)) : "?";
            this.lblMax.Text = max.HasValue ? Convert.ToString(max) : "?";
            this.lblMin.Text = min.HasValue ? Convert.ToString(min) : "?";
            this.lblSum.Text = sum.HasValue ? Convert.ToString(sum) : "?";
            this.lblTotal.Text = total.HasValue ? Convert.ToString(total) : "0";
        }

        private void correctTextBox(object sender, EventArgs e)
        {
            TextBox current = (TextBox)sender;

            if (current.Text.Length == 1)
            {
                char[] minus = current.Text.ToCharArray();
                if (minus[0] == '-' || minus[0] == '+')
                {
                    current.Text = "";
                }
            }

        }
   
        private void btnClear_Click(object sender, EventArgs e)
        {

            for (int i = 0; i < 3; i++) 
            {
                for (int j = 0; j < 3; j++)
                {
                    this.txtMatrix[i, j].Text = "";
                }
            }

            this.lblAverage.Text = "?";
            this.lblMax.Text = "?";
            this.lblMin.Text = "?";
            this.lblSum.Text = "?";
            this.lblTotal.Text ="0";
        }

        private void txt02_TextChanged(object sender, EventArgs e)
        { TextBox current = (TextBox)sender;
            try
            {
                char[] array = current.Text.ToCharArray();
                if (current.Text.Length == 1 && (array[0] == '+' || array[0] == '-')) {
                    return;
                }
                int num = Int32.Parse(current.Text);
            }
            catch {
                current.Text = "";
            }
        }
    }
}
